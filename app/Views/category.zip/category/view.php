<!-- Page Content -->
<div class="container">
 <?php 
  $rolr = $this->user->role;
  $kkar = $this->db->query("SELECT * FROM permission_new WHERE nname = '".$rolr."'")->row_array();
?>

<h3>
  <?= label("Categories"); ?> 
  <?php if($kkar['caaa'] == 1) { ?>
    <button style="float: right;" class="btn btn-primary btn-green" type="button" data-toggle="modal" data-target="#Addcategory">
      <?= label("AddCategory"); ?>
    </button>
  <?php } ?>
</h3>
<hr>

<div class="row mt-3">
  <div class="table-responsive">
    <table id="Table" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead class="sticky-header">
        <tr>
          <th style="width:40px;">SN</th> 
          <th style="width:80px;"><?= label("Category"); ?> <?= label("Id"); ?></th>
          <th><?= label("CategoryName"); ?></th>
          <th><?= label("CreatedAt"); ?></th>
          <th><?= label("Action"); ?></th>
        </tr>
      </thead>

      <tbody>
        <?php 
        $sn = 1; // Serial Number Counter
        foreach ($categories as $category): ?>
          <tr>
            <td><?= $sn++; ?></td>
            <td><?= $category->id; ?></td>
            <td><?= $category->name; ?></td>
            <td><?= date("d-m-Y H:i:s", strtotime($category->created_at)); ?></td>
            <td>
              <div class="btn-group">
                <?php if($kkar['caad'] == 1 && $category->id > 12) { ?>
                  <button class="btn btn-danger btn-sm delete-btn" data-id="<?= $category->id; ?>">
                    <i class="fa fa-times"></i>
                  </button>
                <?php } ?>
                <?php if($kkar['caae'] == 1) { ?>
                  <a class="btn btn-info btn-sm" href="categories/edit/<?= $category->id; ?>" data-toggle="tooltip" title="<?= label('Edit'); ?>">
                    <i class="fa fa-pencil"></i>
                  </a>
                <?php } ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
</div>
<!-- /.container -->

<!-- Modal for Adding Category -->
<div class="modal fade" id="Addcategory" tabindex="-1" role="dialog">
 <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?= label("AddCategory"); ?></h4>
      </div>
      <?= form_open_multipart('categories/add'); ?>
      <div class="modal-body">
        <div class="form-group">
          <label for="CategoryName"><?= label("CategoryName"); ?></label>
          <input type="text" maxlength="50" name="name" class="form-control" id="CategoryName" placeholder="<?= label("CategoryName"); ?>" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?= label("Close"); ?></button>
        <button type="submit" class="btn btn-add"><?= label("Submit"); ?></button>
      </div>
      <?= form_close(); ?>
    </div>
 </div>
</div>
<!-- /.Modal -->

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?= label("Are you sure?"); ?></h4>
      </div>
      <div class="modal-body">
        <p><?= label("Do you really want to delete this category?"); ?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?= label("Cancel"); ?></button>
        <a href="#" id="confirmDelete" class="btn btn-danger"><?= label("Yes, Delete"); ?></a>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript for Delete Confirmation -->
<script>
document.addEventListener("DOMContentLoaded", function() {
  let deleteBtns = document.querySelectorAll(".delete-btn");
  let confirmDeleteBtn = document.getElementById("confirmDelete");

  deleteBtns.forEach(button => {
    button.addEventListener("click", function() {
      let categoryId = this.getAttribute("data-id");
      confirmDeleteBtn.setAttribute("href", "categories/delete/" + categoryId);
      $("#deleteModal").modal("show");
    });
  });
});
</script>

<!-- CSS for Sticky Header & No Vertical Scaling -->
<style>
  /* Make header sticky */
  .sticky-header {
    position: sticky;
    top: 0;
    background: #f8f9fa;
    z-index: 100;
  }

  /* Ensure full-width table without vertical scrolling */
  .table-responsive {
    overflow-x: auto;
    white-space: nowrap;
  }

  /* Fix modal header */
  .modal-header {
    background: #007bff;
    color: white;
  }

  /* Improve button spacing */
  .btn-group .btn {
    margin-right: 5px;
  }
</style>
