<!-- Page Content -->
<div class="container">
 <?php 
  $rolr = $this->user->role;
  $kkar = $this->db->query("SELECT * FROM permission_new WHERE nname = '".$rolr."'")->row_array();
?>

<h3>
  <?= label("Brand"); ?> 
  <?php if($kkar['bra'] == 1){ ?>
    <button style="float: right;" class="btn btn-primary btn-green" type="button" data-toggle="modal" data-target="#Addcategory">
      <?= label("Add Brand"); ?>
    </button>
  <?php } ?>
</h3>
<hr>

<div class="row mt-3">
  <table id="Table" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th style="width:40px;">SN</th> 
        <th style="width:60px;"><?= label("Brand"); ?> <?= label("ID"); ?></th>
        <th><?= label("Brand"); ?> <?= label("Name"); ?></th>
        <th><?= label("CreatedAt"); ?></th>
        <th><?= label("Action"); ?></th>
      </tr>
    </thead>

    <tbody>
      <?php 
      $categories = $this->db->query("SELECT * FROM brand ORDER BY name ASC")->result();
      $sn = 1; // Serial Number Counter
      foreach($categories as $category) { ?>
        <tr>
          <td><?= $sn++; ?></td>
          <td><?= $category->id; ?></td>
          <td><?= $category->name; ?></td>
          <td><?= date("d-m-Y H:i:s", strtotime($category->created_at)); ?></td>
          <td>
            <div class="btn-group">
              <?php if($kkar['brd'] == 1) { ?>
                <button class="btn btn-danger btn-sm delete-btn" data-id="<?= $category->id; ?>">
                  <i class="fa fa-times"></i>
                </button>
              <?php } ?>
              <?php if($kkar['bre'] == 1) { ?>
                <a class="btn btn-info btn-sm" href="brand/edit/<?= $category->id; ?>" data-toggle="tooltip" title="<?= label('Edit'); ?>">
                  <i class="fa fa-pencil"></i>
                </a>
              <?php } ?>
            </div>
          </td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
</div>
</div>
<!-- /.container -->

<!-- Modal for Adding Brand -->
<div class="modal fade" id="Addcategory" tabindex="-1" role="dialog">
 <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?= label("Add"); ?></h4>
      </div>
      <?= form_open_multipart('brand/add'); ?>
      <div class="modal-body">
        <div class="form-group">
          <label for="CategoryName"><?= label("Brand Name"); ?></label>
          <input type="text" maxlength="50" name="CategoryName" class="form-control" id="CategoryName" placeholder="<?= label("Brand Name"); ?>" required>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?= label("Close"); ?></button>
        <button type="submit" class="btn btn-add"><?= label("Submit"); ?></button>
      </div>
      <?= form_close(); ?>
    </div>
 </div>
</div>
<!-- /.Modal -->

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title"><?= label("Are you sure?"); ?></h4>
      </div>
      <div class="modal-body">
        <p><?= label("Do you really want to delete this brand?"); ?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal"><?= label("No"); ?></button>
        <a href="#" id="confirmDelete" class="btn btn-danger"><?= label("Yes, Delete"); ?></a>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript for Delete Confirmation -->
<script>
document.addEventListener("DOMContentLoaded", function() {
  let deleteBtns = document.querySelectorAll(".delete-btn");
  let confirmDeleteBtn = document.getElementById("confirmDelete");

  deleteBtns.forEach(button => {
    button.addEventListener("click", function() {
      let brandId = this.getAttribute("data-id");
      confirmDeleteBtn.setAttribute("href", "brand/delete/" + brandId);
      $("#deleteModal").modal("show");
    });
  });
});
</script>
