<!-- Include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="container">
  <?php 
  $rolr = $this->user->role;
  $kkar = $this->db->query("SELECT * FROM permission_new WHERE nname='" . $rolr . "'")->row_array();
  $ikkxm = $this->db->query("SELECT * FROM settings WHERE id=1")->row_array();
  ?>
  <h3><?= label("Customers"); ?>
    <?php if ($kkar['cua'] == 1) { ?>
      <button style="float: right;" type="button" class="btn btn-primary btn-green" data-toggle="modal" data-target="#AddCustomer">
        <?= label("AddCustomer"); ?>
      </button>
    <?php } ?>
  </h3>
  <hr>

  <div class="row" style="margin-top:20px;">
    <table id="Table" class="table table-striped table-bordered" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th>SN</th>
          <th><?= label("ID"); ?></th>
          <th><?= label("CustomerName"); ?></th>
          <th><?= label("CustomerPhone"); ?></th>
          <th class="hidden-xs"><?= label("CustomerEmail"); ?></th>
          <th class="hidden-xs"><?= label("CustomerDiscount"); ?></th>
          <th class="hidden-xs"><?= label("Point"); ?></th>
          <th class="hidden-xs"><?= label("CreatedAt"); ?></th>
          <th><?= label("Action"); ?></th>
        </tr>
      </thead>
      <tbody>
        <?php 
        $sn = 1; // Initialize Serial Number
        foreach ($customers as $customer): ?>
          <tr>
            <td><?= $sn++; ?></td>
            <td><?= $customer->id; ?></td>
            <td><?= ucfirst($customer->name); ?></td>
            <td><?= $customer->phone; ?></td>
            <td class="hidden-xs"><?= $customer->email; ?></td>
            <td class="hidden-xs"><?= $customer->discount; ?></td>
            <td class="hidden-xs"><?= $customer->tot_creaditpoint; ?></td>
            <td class="hidden-xs"><?= date("d-m-Y H:i:s", strtotime($customer->created_at)); ?></td>
            <td>
              <div class="btn-group">
                <?php if ($kkar['cud'] == 1) { ?>
                  <a class="btn btn-danger" href="javascript:void(0)" onclick="confirmDelete(<?= $customer->id; ?>)">
                    <i class="fa fa-trash"></i>
                  </a>
                <?php } ?>
                <?php if ($kkar['cue'] == 1 && $ikkxm['ct_mgt'] == 0) { ?>
                  <a class="btn btn-info" href="customers/edit/<?= $customer->id; ?>">
                    <i class="fa fa-pencil"></i>
                  </a>
                <?php } ?>
                <?php if ($kkar['cue'] == 1 && $ikkxm['ct_mgt'] == 1) { ?>
                  <a class="btn btn-primary" href="customers/viewcustomer/<?= $customer->id; ?>?tab=setting">
                    <i class="fa fa-eye"></i>
                  </a>
                <?php } ?>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
    
 <script>
  function confirmDelete(customerId) {
    Swal.fire({
      title: '<div style="background: #2c3e50; color: #fff; padding: 12px; border-radius: 6px 6px 0 0; font-size: 18px;">Delete Supplier</div>',
      html: '<p style="margin: 20px 0; font-size: 16px;">Do you really want to delete this supplier?</p>',
      showCancelButton: true,
      confirmButtonColor: "#E74C3C",
      cancelButtonColor: "#BDBDBD",
      confirmButtonText: "Yes, Delete",
      cancelButtonText: "Cancel",
      customClass: {
        popup: 'custom-popup',
        actions: 'custom-actions',
        confirmButton: 'custom-confirm',
        cancelButton: 'custom-cancel'
      }
    }).then((result) => {
      if (result.isConfirmed) {
        window.location.href = "customers/delete/" + customerId;
      }
    });
  }
</script>

<style>
  /* Custom Styling for SweetAlert */
  .swal2-popup.custom-popup {
    border-radius: 6px;
    text-align: center;
    width: 420px;
    padding: 0;
    overflow: hidden;
  }
  
  .swal2-title {
    display: none !important;
  }

  .swal2-html-container {
    padding: 20px;
  }

  .swal2-actions.custom-actions {
    padding: 15px;
    display: flex;
    justify-content: center;
    gap: 10px;
  }

  .swal2-confirm.custom-confirm {
    background-color: #E74C3C !important;
    border-radius: 4px;
    font-size: 14px;
    padding: 8px 18px;
  }

  .swal2-cancel.custom-cancel {
    background-color: #BDBDBD !important;
    color: #000 !important;
    border-radius: 4px;
    font-size: 14px;
    padding: 8px 18px;
  }
</style>
