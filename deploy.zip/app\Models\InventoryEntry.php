<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InventoryEntry extends Model
{
    use HasFactory;

    protected $fillable = [
        'store_id',
        'entry_no',
        'entry_date',
        'type',
        'total_amount',
        'notes',
        'status',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'entry_date'   => 'date',
            'total_amount' => 'decimal:2',
        ];
    }

    public function store()
    {
        return $this->belongsTo(Store::class);
    }

    public function items()
    {
        return $this->hasMany(InventoryEntryItem::class);
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
